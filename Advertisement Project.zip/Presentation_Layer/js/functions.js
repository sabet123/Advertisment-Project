// JavaScript Document

function post_form(form) {
	document.getElementById(form).submit();
}