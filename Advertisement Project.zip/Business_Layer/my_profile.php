<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>My Profile</title>
    <link rel="stylesheet" href="../Presentation_Layer/styles/default.css" />
</head>

<body>
<?php
        include("includes/header.php");
    ?>
    <div class="width-100percent">
    	<div style="min-height:350px;width:1000px;margin:0 auto;">
        	<div style="margin-left:65px;margin-right:65px;">
            	<br />
                <table cellspacing="0">
                	<tr style="background-color:rgb(174,75,126);color:white;">
                        
                    
                </table>
            	 	 	 	 	
            </div>
        </div>
    </div>
    <?php
        include("includes/footer.php");
    ?>
</body>
</html>