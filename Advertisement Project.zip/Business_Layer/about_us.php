<?php
	include('includes/config.php');
	//echo $_SESSION['user_id'];
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>About Us</title>
    <link rel="stylesheet" href="../Presentation_Layer/styles/default.css" />
</head>

<body>
<?php
	include("includes/header.php");
?>

    <div class="width-100percent">
    	<div style="min-height:410px;width:1000px;margin:0 auto;">
        	<div style="margin-left:65px;margin-right:65px;">
                 <h3>Purpose</h3>
                    <p style="margin-left:90px;line-height:30px;">
                    	The main purpose of this website is to promote, advertise and share your 		
                        contact information with the whole world. Besides, a complete list is 
                        given below.
                        <ol type="1" style="line-height:30px;margin-left:90px;">
                        	<li>This website will share your company contact information with the 
                            	whole world
                            </li>
                            <li>This website will help you promote your business</li>
                            <li>This website will help you in advertising new jobs and vacancies 
                            	in your company.
                            </li>
                            <li>Any body can search and see your business contact information like
                            phone number, email address and even fax number. so the person can 	
                            find your company and he / she could be one of your precious clients
                            </li>
                            <li>Your company address will be shown over a map to the searcher, so 	
                            that he can plan his route to reach your office.</li>
                            <li>You can add branches and branch contact info in the future using 
                            your account in this website.</li>
                        </ol>
                        
                    </p>
                <h3>Information about company</h3>
                	<p style="margin-left:90px;line-height:30px;">
                    	By this website you can advertise ang will grow faster.
                        <ol type="1" style="line-height:30px;margin-left:90px;">
                        	<li>Web Development
                                <ol type="a">
                                	The following technologies are used for web development.
                                	<li>H.T.M.L</li>
                                    <li>C.S.S</li>
                                    <li>Javascript</li>
                                    <li>JQuery</li>
                                    <li>P.H.P</li>
                                    <li>MySQL</li>
                                </ol>
                            </li>
                            
                            <li>Desktop Applications Development
                            	<ol type="a">
                                	The following technologies are used for desktop applications development.
                                	<li>JAVA (J2SE)</li>
                                    <li>MySQL</li>
                                    <li>PostGREsql</li>
                                    <li>Swing</li>
                                </ol>
                            </li>
                        </ol>
                    </p>
            </div>
        </div>
    </div>

<?php
	include("includes/footer.php");
?>
</body>
</html>