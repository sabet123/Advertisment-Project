        <div class="footer">
        	<ul class="footer-menus">
            	<li><a href="home.php" style="font-size:12px;float:left;">Home</a></li>
                <li style="font-size:12px;float:left;margin:0px;">|</li>
                <li><a href="jobs.php" style="font-size:12px;float:left;">Find Job</a></li>
                <li style="font-size:12px;float:left;margin:0px;">|</li>
                <li><a href="about_us.php" style="font-size:12px;float:left;">About Us</a></li>
                <li style="font-size:12px;float:left;margin:0px;">|</li>
                <li>
                	<a href="contact_us.php" style="font-size:12px;float:left;">Contact Us</a>
                </li>
                <li style="font-size:12px;float:left;margin:0px;">|</li>
                <li><a href="join_us.php" style="font-size:12px;float:left;">Join Us</a></li>
                <li style="font-size:12px;float:left;margin:0px;">|</li>
                <li><a href="feed_back.php" style="font-size:12px;float:left;">Feed Back</a></li>
                <li style="color:white;float:right;margin-top:5px;font-size:12px;">&copy;2014</li>
            </ul>
        </div>
